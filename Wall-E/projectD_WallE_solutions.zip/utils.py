import random
import numpy

def transpose(list2D):
    '''
    Transpose a 2D list 
    For example, tranpose([[1,2,3],[4,5,6]]) returns [[1,4],[2,5],[3,6]]
    '''
    tmp = list(zip(*list2D))
    list2D = [list(i) for i in tmp]

    return list2D

def generate_2D_map(Lx=1, Ly=1, nvaluable=0, nexplosive=0, ncrater=0):
    '''
    Generate a 2D list of dimensions Lx * Ly.
    That is, the list has Lx elements, and each element is a list of Ly elements.

    Each element in the list takes value 0, 1, 2, or 3.
    The list contains nvaluable 1's, nexplosive 2's, and ncrater 3's, the rest being 0.

    Which element takes what value is random, except that the (0,0) element should be 0.

    The random numbers are generated from a seed (default value = 20).  Same seed
    always produces the same squence of random numbers (pseudo random number to be exact)

    For example, using default seed value, the output for generate_2D_map(4,3,1,1,1) is
    [[0, 0, 0], [0, 0, 1], [2, 0, 0], [0, 0, 3]]

    '''
    seed = 20
    random.seed(seed)

    nclear = Lx*Ly - nvaluable - nexplosive - ncrater
    grids = [0]*nclear
    grids += [1]*nvaluable
    grids += [2]*nexplosive
    grids += [3]*ncrater

    # Shuffle the grids but the first grid should be 0
    tmp = grids[1:]
    random.shuffle(tmp)
    grids = [0] + tmp

    # Convert 1D list to 2D list
    map2D = [grids[i:i+Ly] for i in range(0, len(grids), Ly)]

    return map2D


def write_2D_to_txt(map2D, filename):

    #####################################################################
    # TODO: Write 2D list map2D into a file with given filename.        #
    #                                                                   #
    #       To be consistent with our reading habit,                    #
    #       we write in a way that x is the horizontal direction and    #
    #       x coordinate increases toward the right and y is the        #
    #       vertical direction, and y coordinate increases              #
    #       toward the bottom.                                          # 
    #                                                                   #
    #       For example:                                                #
    #                                                                   #
    #       map2D = [[0, 1], [0, 0], [0, 1], [1, 0]]                    #
    #       write_2D_to_txt(map2D, 'testmap.txt')                       #
    #       should generate a file testmap.txt that reads               #
    #                                                                   #
    #       0 0 0 1                                                     #
    #       1 0 1 0                                                     #
    #                                                                   #
    #       Note: keep one space between the numbers and there is       #
    #       NO space at the end of the line.                            #  
    #                                                                   #
    #       Make use of the transpose() function defined above.         #
    #####################################################################   

    map2D = transpose(map2D)

    f = open(filename, 'w')

    for row in map2D:
        s = ''
        for i in range(len(row)):
            s += str(row[i])

            if i != len(row)-1:
                s += ' '

        s += '\n'
        f.write(s)
    f.close() 

def read_2D_from_txt(filename):

    #####################################################################   
    # TODO: Read 2D map from a txt file.                                #
    #       Return a 2D list                                            #
    #                                                                   #
    #       It is the reverse operation to write_2D_to_txt() function.  #
    #       If a map file reads                                         #
    #                                                                   #
    #       0 0 0 1                                                     #
    #       1 0 1 0                                                     #
    #                                                                   #
    #       Then the return should be [[0,1], [0,0], [0,1], [1,0]]      #
    #       Make use of the transpose() function defined above.         #
    #####################################################################   

    array2D = []

    with open(filename, 'r') as f:
        for line in f.readlines():
            array2D.append(line.split())

    for i in range(len(array2D)):
        for j in range(len(array2D[0])):
            array2D[i][j] = int(array2D[i][j])

    # transpose
    array2D = transpose(array2D)

    return array2D

def print_2D(map2D):
    ''' 
    Print the 2D map to the screen, choice of x, y directions is the 
    same as write_2D_to_txt() function 
    '''

    map2D = transpose(map2D)
    for row in map2D:
        s = [str(item) for item in row]
        print(" ".join(s))

def test_transpose():
    '''test transpose() function'''

    list2D = [[1, 2, 3], [4, 5, 6]]
    answer = [[1, 4], [2, 5], [3, 6]]

    print("\tTesting transpose() ...", end=" ")
    if transpose(list2D) != answer:
        print("\t failed")
    else:
        print("\t passed")


def test_generate_2D_map():
    '''test generate_2D_map() function'''

    map2D = generate_2D_map(4, 3, 1, 1, 1)

    print("\tTesting generate_2D_map() ...", end=" ")
    if map2D == [[0, 0, 0], [0, 0, 1], [2, 0, 0], [0, 0, 3]]:
        print("\t passed")
    else:
        print("\t failed")

def test_write_2D_to_txt():
    '''test write_2D_to_txt() function'''

    write_2D_to_txt(generate_2D_map(4,3,1,1,1),'testmap.txt')

    f = open('testmap.txt','r')
    content = f.readlines()
    f.close()

    f = open('testmap_sol.txt','r')
    sol = f.readlines()
    f.close()

    print("\tTesting write_2D_to_txt() ...", end=" ")
    if content == sol:
        print("\t passed")
    else:
        print("\t failed")

def test_read_2D_from_txt():
    '''test read_2D_from_txt() function'''

    map2D = read_2D_from_txt('testmap_sol.txt')

    print("\tTesting read_2D_from_txt() ...", end=" ")
    if map2D == [[0, 0, 0], [0, 0, 1], [2, 0, 0], [0, 0, 3]]:
        print("\t passed")
    else:
        print("\t failed")


if __name__=="__main__":
    '''Test the implementation of the utility functions'''

    print("\nTesing utilitiy functions")

    test_transpose()
    test_generate_2D_map()
    test_write_2D_to_txt()
    test_read_2D_from_txt()
