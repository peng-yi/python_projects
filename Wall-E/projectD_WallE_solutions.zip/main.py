from utils import *
from field import *
from robot import *
import random
import copy
import os
import matplotlib.pyplot as plt
from matplotlib import colors
from matplotlib.patches import Rectangle
import matplotlib.animation as animation

def prepare_fields():
    ''' Prepare a list of fields for final evaluation '''

    fields =  []
    fields.append(field2D(generate_2D_map(10,10,10,10,10)))
    fields.append(field2D(generate_2D_map(15,15,15,15,15)))
    fields.append(field2D(generate_2D_map(20,20,20,20,20)))
    fields.append(field2D(generate_2D_map(25,25,25,25,25)))
    fields.append(field2D(generate_2D_map(30,30,30,30,30)))
    return fields


def initplot():
    ''' initial setup for animation '''
    pass


def showFrame(datapack):
    ''' Show a frame for animation '''

    plotGrid, batt, initbatt, nRecyclable, ntotRecyclable, nExplosive, ntotExplosive = datapack
    
    plt.subplots_adjust(left=0.1, right=0.9, top=0.9, bottom=0.15)
    
    ax.clear()
    # Create legends
    xside = 0.03
    yside = xside/0.75

    ax.add_patch(Rectangle((0, 1.05), xside, yside, transform=ax.transAxes, facecolor = 'green', fill=True,clip_on=False))
    ax.add_patch(Rectangle((0.25, 1.05), xside, yside, transform=ax.transAxes, facecolor = 'blue', fill=True,clip_on=False))
    ax.add_patch(Rectangle((0.55, 1.05), xside, yside, transform=ax.transAxes, facecolor = 'red', fill=True,clip_on=False))
    ax.add_patch(Rectangle((0.85, 1.05), xside, yside, transform=ax.transAxes, facecolor = 'brown', fill=True,clip_on=False))

    ax.text(0.05, 1.05, 'WALL-E', transform=ax.transAxes, size=12)
    ax.text(0.30, 1.05, 'recyclable', transform=ax.transAxes, size=12)
    ax.text(0.60, 1.05, 'explosive', transform=ax.transAxes, size=12)
    ax.text(0.90, 1.05, 'crater', transform=ax.transAxes, size=12)
    
    # create discrete colormap
    cmap = colors.ListedColormap(['white','blue','red','brown','green'])
    bounds = [-0.5, 0.5, 1.5, 2.5, 3.5, 4.5]
    norm = colors.BoundaryNorm(bounds, cmap.N)
    ax.imshow(plotGrid, cmap=cmap, norm=norm)

    # draw gridlines
    ax.grid(b=True, which='major', axis='both', linestyle='-', color='k', linewidth=1)
    Lx = len(plotGrid[0])                   # note plotGrid is transposed
    Ly = len(plotGrid)
    xticks = [i-0.5 for i in range(Lx+1)]
    yticks = [i-0.5 for i in range(Ly+1)]
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)

    ax.tick_params(length=0)    # no ticks
    ax.set_xticklabels([])      # no tick labels
    ax.set_yticklabels([])
    
    # annotation
    batt_text = ax.text(0.0, -0.08, '', transform=ax.transAxes, size=12)
    recy_text = ax.text(0.5, -0.08, '', transform=ax.transAxes, size=12)
    expl_text = ax.text(0.5, -0.16, '', transform=ax.transAxes, size=12)
            
    batt_text.set_text("{}/{} battery left".format(batt,initbatt))
    recy_text.set_text("{}/{} recyclables collected".format(nRecyclable, ntotRecyclable))
    expl_text.set_text("{}/{} explosives cleared".format(nExplosive, ntotExplosive))


def simulate(WALLE, field):
    ''' Simulate the work, generate data for every frame '''

    ntotRecyclable = field.nRecyclable
    ntotExplosive  = field.nExplosive

    # robot starts working
    WALLE.reportStatus()

    while WALLE.batt > 0 and (field.nRecyclable >0 or field.nExplosive >0):

        WALLE.selectNextMove(field)
        WALLE.action(field)
        WALLE.reportStatus()

        plotGrid = copy.deepcopy(field.map)
        plotGrid[WALLE.x][WALLE.y] = 4          # to color WALLE on the map
        plotGrid = transpose(plotGrid)

        datapack = (plotGrid, WALLE.batt, WALLE.battlevels[0], WALLE.nRecyclable, ntotRecyclable, 
                            WALLE.nExplosive, ntotExplosive)
        yield datapack

    plotGrid = copy.deepcopy(field.map)
    plotGrid[WALLE.x][WALLE.y] = 4
    plotGrid = transpose(plotGrid)

    datapack = (plotGrid, WALLE.batt, WALLE.battlevels[0], WALLE.nRecyclable, ntotRecyclable, 
                            WALLE.nExplosive, ntotExplosive)
    yield datapack

    WALLE.writeWorkLog('work.log')

    print("Work report:")
    print("    {}/{} recyclables collected".format(WALLE.nRecyclable, ntotRecyclable))
    print("    {}/{} explosives cleared".format(WALLE.nExplosive, ntotExplosive))
    print("    {}/{} battery left".format(WALLE.batt, WALLE.battlevels[0]))
    print()


if __name__ == "__main__":
    ''' Simulate and visualize WALLE's work in the field '''

    random.seed(30)
    
    #############################################################
    # TODO: Choose to run demo or final evaluation              #
    #############################################################
    
    run = 'demo'   # choose 'demo' or 'final'
    
    if run == 'demo':

        print("\n#-------- Demonstration case --------#\n")

        #########################################################
        # TODO: Customize field and WALLE for the simulation.   #
        #       Set show_anime to decide if you want animation. #
        #       Set frame_interval to adjust animation speed.   #
        #       Set generate_gif if you want a gif animation.   #
        #       Set gif_fps to adjust gif animation speed.      #
        #                                                       #
        #       Modify as needed to test your program.          #
        #                                                       #
        #       Check demo.txt for the demo case trajectory.    #
        #########################################################
    
        # Animation setup
        
        show_anim = True
        frame_interval = 100                    # unit milliseconds
        generate_gif = not True and show_anim   # will take a few seconds to do
        gif_fps= 4                              # gif frames per second

        # Choose field and robot
    
        field = field2D(generate_2D_map(6,5,4,4,4))
        WALLE = robot(0, 0, 200)
    
        #########################################################
        #                 END OF DEMO CUSTOMIZATION             #
        #########################################################
        
        print("Field map:\n")
    
        print_2D(field.map)
    
        print("\nWALLE Gen {}\n".format(WALLE.version))
    
        write_2D_to_txt(field.map, 'demo.txt')
        os.system("echo # Field map above >> demo.txt")
        s = "# WALLE Gen {}".format(WALLE.version)
        os.system("echo "+s+" >> demo.txt")
        
        # Run simulation, save frames
        
        animFrames = []
        for frame in simulate(WALLE, field):
               animFrames.append(frame)
        os.system("more work.log >>demo.txt")
   
        # Show animation
       
        if show_anim:
            # To show animation, go to: Tools > Preferences > IPython Console > Graphics > Backend and change it from "Inline" to "Automatic"
            fig, ax = plt.subplots()
   
            anim = animation.FuncAnimation(fig, showFrame, frames=animFrames,
                        interval=frame_interval, repeat=False, init_func=initplot)
         
            if generate_gif:
                writergif = animation.PillowWriter(fps=gif_fps)
                anim.save('demo.gif', writer=writergif)
    
            plt.show()
        

    elif run == 'final':
        print("\n#-------- Final evaluation --------#\n")
        
        start_batt = 500
    
        # Gen 1 WALLE performance
        fields = prepare_fields()
        for i, field in enumerate(fields):
            WALLE = robot(0,0,start_batt)          # need to initialize WALLE after every job
            print("WALLE Gen {} - field map {}".format(WALLE.version, i+1))
            for step in simulate(WALLE, field):
                pass
    
        # Gen 2 WALLE performance
        fields = prepare_fields()           # need to generate fields again since it was cleared
        for i, field in enumerate(fields):
            WALLE = robotGen2(0,0,start_batt)
            print("WALLE Gen {} - field map {}".format(WALLE.version, i+1))
            for step in simulate(WALLE, field):
                pass
    
