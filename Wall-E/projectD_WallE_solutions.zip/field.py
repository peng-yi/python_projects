from utils import *
import copy


class field2D:
    '''
    This is a class of rectangle fields. 
    A field is width Lx and height Ly, divided by Lx * Ly square grids.
    Each grid can be of different type, e.g., a recyclible equipment, an undetonated explosive,
    a normal space, or a crater.
    A field2D instance is initialized by a 2D list, fieldmap, as input parameter.
    '''
    def __init__(self, fieldmap):

        #########################################################
        # TODO: Intialize the field with 2D list fieldmap,      #
        #       which contains the values for each grid.        #
        #                                                       #
        #       Calculate the width and length of the field     #
        #       Initialize other member attributes, call a      #
        #       method if needed.                               #
        #                                                       #
        #       member attributes:                              #
        #       map, Lx, Ly, nRecyclable, nExplosive, magMap    #
        #########################################################

        self.map = fieldmap             # field map
        self.Lx = len(fieldmap)         # width of the map
        self.Ly = len(fieldmap[0])      # height of the map

        self.nRecyclable = 0
        self.calcNumRecyclable()

        self.nExplosive = 0
        self.calcNumExplosive()

        self.magMap = []
        self.calcMagMap()

    def calcNumRecyclable(self):

        #########################################################
        # TODO: Compute the number of recylicable materials     #
        #       in the field.  Pass its value to member         #
        #       attribute nRecyclable.  No return needed.       #
        #########################################################
        n = 0 
        for row in self.map:
            for i in row:
                if i == 1:
                    n += 1

        self.nRecyclable = n

    def calcNumExplosive(self):

        #########################################################
        # TODO: Compute the number of undetonated explosives    #
        #       in the field.  Pass its value to member         #
        #       attribute nExplosive.  No return needed.        # 
        #########################################################
        n = 0 
        for row in self.map:
            for i in row:
                if i == 2:
                    n += 1

        self.nExplosive = n
     
    def calcMagMap(self):

        #################################################################
        # TODO: Compute the magnetic field for all grids as a 2D list.  #
        #       Pass the magnetic field to member attribute             #
        #       magMap.  No return needed.                              # 
        #                                                               #
        # Note: If case you want to copy a list, use the copy module.   #
        #       Copy a one-dimensional list,  b = copy.copy(a).         #    
        #       Copy a multi-dimensional list,  b = copy.deepcopy(a).   #
        #################################################################

        magMap = copy.deepcopy(self.map)
        for i in range(self.Lx):
            for j in range(self.Ly):
                magMap[i][j] = 0

        # loop over map and find objects
        for x in range(self.Lx):
            for y in range(self.Ly):

                # find an object, compute the magnetic field at all grids
                if self.map[x][y] == 1 or self.map[x][y] == 2:

                    for i in range(self.Lx):
                        for j in range(self.Ly):
                            distanceSq = (i-x)**2 + (j-y)**2

                            #if distanceSq <= 25 and distanceSq > 0:
                            if distanceSq > 0:
                                magMap[i][j] += 1.0/(distanceSq**1.5)

        self.magMap = magMap

    def getGrid(self, x, y):

        #################################################################
        # TODO: Return the value of the grid at coordinates (x,y).      #
        #################################################################

        return self.map[x][y]

    def setGrid(self, x, y, value):

        #################################################################
        # TODO: Set the value of the grid at coordinates (x,y) to the   #
        #       given value.  No return needed.                         #
        #################################################################

        self.map[x][y] = value

    def getMagGrid(self, x, y):

        #################################################################
        # TODO: Return the value of the magnetic field at grid (x,y).   #
        #################################################################

        return self.magMap[x][y]

    def update(self):

        #################################################################
        # TODO: Update the remaining number of recyclables, and the     #
        #       remaining number of explosives, and recalculate the     #
        #       magnetic field map due to the change of the map         #
        #       (recyclable collected and/or explosive cleared).        #
        #       No return needed.                                       #
        #                                                               #
        #       Only use methods implemented above.                     #
        #################################################################
        
        self.calcNumRecyclable()
        self.calcNumExplosive()
        self.calcMagMap()


if __name__ == "__main__":
    pass

    #################################################################
    # TODO (optional): use this area to test your implementation.   #
    #       Some example statements are given.                      #
    #################################################################

    map2D = generate_2D_map(4,3,1,0,0)
    print_2D(map2D)
    field = field2D(map2D)

    print(field.Lx, field.Ly)
    print(field.getGrid(0,0))
    field.setGrid(0,0,1)
    print_2D(map2D)

    #################################################################
    #                      END OF YOUR CODE                         #
    #################################################################
