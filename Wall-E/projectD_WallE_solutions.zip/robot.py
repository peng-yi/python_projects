from utils import *
from field import *
import random

class robot:
    '''
    This is a robot class for the 1st generation design
    '''
    def __init__(self, x=0, y=0, batt=100):

        #########################################################################
        # TODO: Intialize the robot with initial position and battery points.   #
        #                                                                       #
        #       member attributes:                                              #
        #       version, x, y, batt, nRecyclable, nExplosive                    #
        #       sensors, actionList, nextMove, actions, positions, battlevels   # 
        #########################################################################

        self.version = 1
        self.x = x                  # (x, y) coordinates
        self.y = y
        self.batt = batt            # current batter level
        self.sensors = []           # 4 optical sensors on the 4 sides of the robot
        self.actionList = ['north', 'east', 'south', 'west', 'clean']
        self.nextMove = 0           # int number representing action to take
                                    # 0='north', 1='east', 2='south', 3='west', 4='clear'
        self.nRecyclable = 0
        self.nExplosive = 0
        self.actions = []           # history of actions, e.g., ['north', 'clear', ...]
        self.positions = []         # history of robot positions, e.g., [(0,0), (0,1), (1,1),...]
        self.battlevels = []        # history of battery level


    def reportStatus(self):
        '''
        Record current position and battery level to member attributes self.positions
        and self.battlevels, both are lists as history records.
        '''
        self.positions.append((self.x, self.y))
        self.battlevels.append(self.batt)


    def readSensors(self, field):

        #################################################################
        # TODO: Use field.getGrid() method to probe the 4 grids         #
        #       immediately adjacent the robot's current location.      #
        #                                                               #
        #       Update member attributes sensors[] in the order of the  #
        #       north, east, south, west directions.                    #
        #                                                               #
        #       The sensor in each direction can take one of the        #
        #       following 5 values:                                     #
        #                                                               #
        #       -1: at the boundary                                     #
        #       0 : normal grid                                         #
        #       1 : recyclable grid                                     #
        #       2 : explosive grid                                      #
        #       3 : crater grid                                         #
        #                                                               #
        #       No return needed.                                       #
        #################################################################

        # initialize sensors
        sensors = [0]*4
        
        # north direction
        if self.y == 0:     sensors[0] = -1
        else:               sensors[0] = field.getGrid(self.x, self.y-1)

        # east direction
        if self.x + 1 == field.Lx:  sensors[1] = -1
        else:                       sensors[1] = field.getGrid(self.x+1, self.y)

        # south direction
        if self.y + 1 == field.Ly:  sensors[2] = -1
        else:                       sensors[2] = field.getGrid(self.x, self.y+1)

        # west direction
        if self.x == 0:             sensors[3] = -1
        else:                       sensors[3] = field.getGrid(self.x-1, self.y)
                
        self.sensors = sensors


    def selectNextMove(self, field):

        #################################################################
        # TODO: select the next move based on sensor information        #
        #                                                               #
        #       pass an integer to member attribute nextMove:           #
        #                                                               #
        #       0:  move north                                          #
        #       1:  move east                                           #
        #       2:  move south                                          #
        #       3:  move west                                           #
        #       4:  collect recyclable and/or clear explosive           #
        #                                                               #
        #       Rread the sensors.                                      #
        #       Then choose 4 if any recyclable or explosive is found   #
        #       in immediately adjacent grids.  Otherwise choose        #
        #       0, 1, 2, or 3 in random.  However, cannot choose the    #
        #       move that get robot out of boundary.                    #
        #                                                               #
        #       No return needed.                                       #
        #################################################################
        
        self.readSensors(field)

        if 1 in self.sensors or 2 in self.sensors:      # any sensor detects an object         
            self.nextMove = 4 
        else:                                           # robot moving
            moves = [0, 1, 2, 3]                        # ['north', 'east', 'south', 'west']
            while True:
                i = random.randint(0,3)
                if self.sensors[i] != -1: 
                    self.nextMove = moves[i]
                    break
    
    def setNextMove(self, strNextMove):

        #################################################################
        # TODO: Set the member attribute nextMove to an integer value   #
        #       based on the given strNextMove.                         #
        #                                                               #
        #       strNextMove         member attribute nextMove           #
        #                                                               #
        #       "north"             0                                   #   
        #       "east"              1                                   #   
        #       "south"             2                                   #   
        #       "west"              3                                   #   
        #       "clean"             4                                   #   
        #################################################################

        if strNextMove == 'north':  self.nextMove = 0
        elif strNextMove == 'east':  self.nextMove = 1
        elif strNextMove == 'south':  self.nextMove = 2
        elif strNextMove == 'west':  self.nextMove = 3
        elif strNextMove == 'clean':  self.nextMove = 4
        else:   print("Error: invalid strNextMove")

    def action(self, field):
        
        #################################################################
        # TODO: Based on the value of member attribute nextMove,        #
        #       call the corresponding method.                          #
        #                                                               #
        #       Also record the action to member attribute actions[].   #
        #       Action is one of the elements in the member attribute   #
        #       actionList, i.e. "north", "east", "south", "west",      #
        #       and "clean".                                            #
        #                                                               #
        #       No return needed.                                       #
        #################################################################

        self.actions.append(self.actionList[self.nextMove])

        if   self.nextMove == 0:  self.moveNorth(field)
        elif self.nextMove == 1:  self.moveEast(field)
        elif self.nextMove == 2:  self.moveSouth(field)
        elif self.nextMove == 3:  self.moveWest(field)
        elif self.nextMove == 4:  self.collect_n_clear(field)
        else:                     pass

    def moveNorth(self, field):

        #################################################################
        # TODO: Determine if robot at the north boundary, if not then   #
        #       move the robot in the north (-y) direction by 1 grid.   #
        #                                                               #
        #       Otherwise do nothing.                                   #
        #       Compute the remaining battery and update member         #
        #       attribute batt.  No return needed.                      #
        #################################################################

        if self.y >0:
            self.y -= 1
            if self.sensors[0]==3:      self.batt -= 5
            elif self.sensors[0]==0:    self.batt -= 1

    def moveEast(self, field):   

        #################################################################
        # TODO: Determine if robot at the east  boundary, if not then   #
        #       move the robot in the east  (+x) direction by 1 grid.   #
        #                                                               #
        #       Otherwise do nothing.                                   #
        #       Compute the remaining battery and update member         #
        #       attribute batt.  No return needed.                      #
        #################################################################

        if self.x < field.Lx-1:
            self.x += 1
            if self.sensors[1]==3:      self.batt -= 5
            elif self.sensors[1]==0:    self.batt -= 1

    def moveSouth(self, field):    

        #################################################################
        # TODO: Determine if robot at the south boundary, if not then   #
        #       move the robot in the south (+y) direction by 1 grid.   #
        #                                                               #
        #       Otherwise do nothing.                                   #
        #       Compute the remaining battery and update member         #
        #       attribute batt.  No return needed.                      #
        #################################################################

        if self.y < field.Ly-1:
            self.y += 1
            if self.sensors[2]==3:      self.batt -= 5
            elif self.sensors[2]==0:    self.batt -= 1

    def moveWest(self,field): 

        #################################################################
        # TODO: Determine if robot at the west  boundary, if not then   #
        #       move the robot in the west  (-x) direction by 1 grid.   #
        #                                                               #
        #       Otherwise do nothing.                                   #
        #       Compute the remaining battery and update member         #
        #       attribute batt.  No return needed.                      #
        #################################################################

        if self.x > 0:
            self.x -= 1
            if self.sensors[3]==3:      self.batt -= 5
            elif self.sensors[3]==0:    self.batt -= 1

    def collect_n_clear(self, field):

        #################################################################
        # TODO: Collect all recyclable materials and clear all          #
        #       undetonated explosives in the 4 grids immediately       #
        #       adjacent the robot.                                     #
        #                                                               #
        #       Once the recyclable/explosive in a grid is              #
        #       collected/cleared, this grid becomes a clean grid.      #
        #                                                               #
        #       Update the field using the update() method in           #
        #       the field class.                                        #
        #                                                               #
        #       Keep track of the numbers of the recyclables/explosives #
        #       collected/cleared, using member attributes nRecycles    #
        #       and nExplosive.                                         #
        #                                                               #
        #       Collecting and clearing do not consume battery.         #
        #                                                               #
        #       No return needed.                                       #
        #################################################################

        x = self.x
        y = self.y

        # grid with a recyclable/explosive is in the north
        if y > 0:
            item = field.getGrid(x, y-1)
            if item == 1 or item == 2:
                if item == 1:
                    self.nRecyclable += 1
                elif item == 2:
                    self.nExplosive += 1

                field.setGrid(x, y-1, 0)

        # grid with a recyclable/explosive is in the east
        if x < field.Lx-1:
            item = field.getGrid(x+1, y)
            if item == 1 or item == 2:
                if item == 1:
                    self.nRecyclable += 1
                elif item == 2:
                    self.nExplosive += 1

                field.setGrid(x+1, y, 0)

        # grid with a recyclable/explosive is in the south
        if y < field.Ly-1:
            item = field.getGrid(x, y+1)
            if item == 1 or item == 2:
                if item == 1:
                    self.nRecyclable += 1
                elif item == 2:
                    self.nExplosive += 1
                field.setGrid(x, y+1, 0)

        # grid with a recyclable/explosive is in the west
        if x > 0:
            item = field.getGrid(x-1, y)
            if item == 1 or item == 2:
                if item == 1:
                    self.nRecyclable += 1
                elif item == 2:
                    self.nExplosive += 1
                field.setGrid(x-1, y, 0)

        field.update()

    def writeWorkLog(self, filename):
        ''' Output the history of positions, battlevels, and actions to a file '''

        f = open(filename,'w')
        f.write("# position, battery, action\n")
        for i in range(len(self.positions)):
            s = "{}, {}, ".format(self.positions[i], self.battlevels[i])

            if i >= len(self.actions):
                s += "none"
            else:
                s += self.actions[i]

            f.write(s+"\n")
        f.close()


class robotGen2(robot):
    '''
    This is a child class to the robot class
    This is the second generation robot, with additional features
    '''
    def __init__(self, x=0, y=0, batt=100):

        #########################################################################
        # TODO: Intialize the second generation robot                           #
        #                                                                       #
        #       addition member attributes:                                     #
        #       magField, prev_magField                                         #
        #########################################################################

        robot.__init__(self, x, y, batt)

        self.version = 2
        self.magField = 0
        self.prev_magField = 0

    def readMagSensor(self, field):

        #################################################################
        # TODO: Update the member attribute magField by calling         #
        #       field.getMagGrid() method.                              #
        #                                                               #
        #       Before the update, the old magField value should be     #
        #       saved to member attribute prev_magFeild.                #
        #                                                               #
        #       No return needed.                                       #
        #################################################################

        self.prev_magField = self.magField
        self.magField = field.getMagGrid(self.x, self.y)

    def selectNextMove(self,field):

        #################################################################
        # TODO: Overload the selectNextMove() method in robot class     #
        #                                                               #
        #       Make use of the magnetic sensor information,            #
        #       in addition to the optical sensors previously used.     #
        #                                                               #
        #       No return needed.                                       #
        #################################################################

        self.readSensors(field)             # read optical sensors
        self.readMagSensor(field)           # read magnetic sensor

        if len(self.actions) > 0:
            last_action = self.actionList.index(self.actions[-1])   #[0,1,2,3,4]
            #print("last_action ", last_action)
            #print("last action = {}".format(self.actionList[last_action]))

        if 1 in self.sensors or 2 in self.sensors:       # any sensor detects an object
            self.nextMove = 4            
        else:
            moves = [0, 1, 2, 3]            # ['north','east','south','west']
            weights = [1, 1, 1, 1]

            if len(self.actions) == 0 or last_action == 4:      # take random direction
                pass
            else:
                if self.magField > self.prev_magField:
                    weights[last_action] *= 5
                elif self.magField < self.prev_magField:
                    weights[last_action] /= 5

            while True:
                i = random.choices(moves, weights)[0]
                if self.sensors[i] != -1: 
                    self.nextMove = moves[i]
                    break



if __name__ == "__main__":
    pass

    #################################################################
    # TODO (optional): use this area to test your implementation.   #
    #       Some example statements are given.                      #
    #################################################################

    map2D = generate_2D_map(4,3,1,0,0)
    print_2D(map2D)
    field = field2D(map2D)

    WALLE = robot(0,0,10)
    WALLE.readSensors(field)
    print(WALLE.sensors)
    print(WALLE.x, WALLE.y, WALLE.batt)
    WALLE.setNextMove("north")
    WALLE.action(field)
    print(WALLE.x, WALLE.y, WALLE.batt)

    #################################################################
    #                      END OF YOUR CODE                         #
    #################################################################
